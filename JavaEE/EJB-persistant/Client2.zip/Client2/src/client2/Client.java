package client2;

import java.io.IOException;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import actions.*;

public class Client {

    public static void main(String[] args) throws NamingException {
        Properties properties = new Properties();
        properties.put(Context.INITIAL_CONTEXT_FACTORY,"org.jboss.naming.remote.client.InitialContextFactory");
        properties.put(Context.PROVIDER_URL, "remote://127.0.0.1:4447");
        properties.put("jboss.naming.client.ejb.context",true);
        Context context = new InitialContext(properties);
        //fasolkaRemote myBean = (fasolkaRemote)context.lookup("EJBModule1/fasolka!dddd.fasolkaRemote");
        //Context jndiContext = getInitialContext();
        //Object ref = jndiContext.lookup("SampleAction/remote");
        SampleActionRemote ar = (SampleActionRemote) context.lookup("EJBModule2/SampleAction!actions.SampleActionRemote");
        System.out.println("XXXXXXXXXXXXXXXX");
        //ar.create("jeden");
	//ar.create("dwa");
	//ar.create("fffffff");
	ar.create("sssss");
        ar.enhancedCreate("www","ggg");
        
//	ar.create("piec", 1);
	//System.out.println(ar.find(1));
	//System.out.println(ar.find(2));
        System.out.println("normal data:");
        final int START = 70;
        final int END = START +10;
        for(int i =START;i<END;i++){
            System.out.println(""+i+". "+ar.find(i));
        }
        System.out.println();
        System.out.println("enhanced data:");
        for(int i =START;i<END;i++){
            System.out.println(""+i+". "+ar.enhancedFind(i));
        }
	//System.out.println(ar.find(123));
    }
}
